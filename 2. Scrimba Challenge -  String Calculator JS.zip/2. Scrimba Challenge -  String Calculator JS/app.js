/*
Part 1 (Calculation): 
    +Your first goal is to solve a simple text-based
        math problem entered in the input field
    +The problem can be add/sub/multiply/divide
    +Here are few examples: 
        "3 + 3" -> 6
        "10 - 3" -> 7
        "44 / 2" -> 22
        "2 * 8" -> 16 
    +When the 'Solve' button is clicked
        -Create a new div with the
            class 'equation-component'
            its text value should be the solution
            to the input equation
        -This element should be added as a child of 
            the `solutionDisplay` div

    Note: You can assume there will always only be 2 values, 
        both whole integers, and always a space between each 
        integer and the operator as in the above examples


Part 2 (Flex Display): 
    Then, you'll Flex your Flexbox skills!
    + Vertically stack the contents of the mainContainer
    + Center the content horizontally
    + Display all components of the equation 
        in the solutionDisplay using a horizontal Flexbox
        with `space around` each component
    
Skills: 
    Event Listeners, String Manipulation, Array Manipulation, 
Arithmetic, DOM Manipulation, Flexbox



STRETCH GOALS:
    +Accept and solve more complex problems with more than 2 inputs
    +Signal the different types of components (operator/value/solution) with different colors
    +Accept strings without spaces
    +Can you improve the overall design?
*/

//Getting UI Elements
const mainContainer = document.getElementById("main-container")
const equationField = document.getElementById("equation-field")
const solveButton = document.getElementById("solve-button")
const solutionDisplay = document.getElementById("solution-display")

//adding event on 'solve' button click
solveButton.addEventListener("click", function() {
    // Clears the solution contents on each click
    solutionDisplay.innerHTML = ``
    
    // Write your code here 👇
    //creating new div
    let newDiv = document.createElement("div");
    //adding the class 'equation-component' to newly created div
    newDiv.classList.add("equation-component");
    //appending the newDiv to the solutionDisplay. i.e; it becomes the child of solutionDisplay.
    solutionDisplay.appendChild(newDiv);
    //getting the input value and storing it in variable.
    let equationText = equationField.value;
    //The split() method is used to split a string into an array of substrings, and returns the new array.
    //spliting the value on the basis of single space. visit hints at the below of code.
    let splitText = equationText.split(" ");
    
    //using switch to check for operator.
    switch(splitText[1]) {
        case '+' : {
            newDiv.textContent = ("Solution : " + `${parseInt(splitText[0]) + parseInt(splitText[2])}`);
            break;
        }
        case '-' : {
            newDiv.textContent = ("Solution : " + `${parseInt(splitText[0]) - parseInt(splitText[2])}`);
            break;
        } 
        case '*' : {
            newDiv.textContent = ("Solution : " + `${parseInt(splitText[0]) * parseInt(splitText[2])}`);
            break;
        } 
        case '/' : {
            newDiv.textContent = ("Solution : " + `${parseInt(splitText[0]) / parseInt(splitText[2])}`);
            break;
        }
        default : {
            newDiv.innerHTML = "Invalid Operator ! <br/> OR <br/> Invalid Input Pattern !";
        }
    }
});

/* 
Hint 1:
    To parse the equation, you can use the "split" method 
    on the equation string to break it up 
    into an array of its components

    Like this:
        let equationString = "3 * 5"
        equationString.split(" ") -> ["3", "*", "5"]
    
Hint 2:
    A switch statement or a chain of if/else statements 
    can help you evaluate which operation to do 
    based on the equation's operator: +, -, *, or / 
    
Hint 3: 
    You can use the built in `parseInt()` to parse a string
    containing an integer value into an integer
    
    Like this:
        let myValue = "42"
        parseInt(myValue) -> 42

Hint 4:
    Row-based Flexbox:
        Horizontal Alignment: `justify-content`
        Vertical Alignment: `align-items`
    
    Column-based Flexbox
        Horizontal Alignment: `align-items`
        Vertical Alignment: `justify-content`
*/