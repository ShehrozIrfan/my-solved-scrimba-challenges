/*
DESCRIPTION:
In this challenge you are asked to change how the logo looks when you click 
the three buttons. This is an excellent challenge for styling elements in 
JavaScript, not CSS.

If the user clicks the first button, I want the text on the 
logo to become black. If the user clicks the second button, 
I want the logo background to become red. If the user clicks the third button,
I would like you to add a shadow to the logo.

event listeners, getElementById, operators

*/

// Write your code here 👇


/*

DETAILED INSTRUCTIONS
1. pick out the neccesary elements from the HTML
2. use eventlisteners on the buttons to envoke functions
3. change the properties of the logo using JavaScript

STRETCH GOALS:
- If any of the buttons are clicked a second time, I want the change they 
  are responsible for to be reversed.
- Can you improve the overall design?

*/

/* ====================================================== */
 
//Getting UI Elements.
let logo = document.querySelector('.logo');
let text = document.querySelector('#text');
let btn1 = document.querySelector('#button-one');
let btn2 = document.querySelector('#button-two');
let btn3 = document.querySelector('#button-three');

//variables.
let flagBtn1 = true;
let flagBtn2 = true;
let flagBtn3 = true;

//button one.
btn1.addEventListener("click", function() {
    if(flagBtn1) {
        text.style.color = "black";
        flagBtn1 = false;
    } else {
        text.style.color = "white";
        flagBtn1 = true;
    }
});
//button two.
btn2.addEventListener("click", function() {
    if(flagBtn2) {
        logo.style.backgroundColor = "red";
        flagBtn2 = false;
    } else {
        logo.style.backgroundColor = " #FF8600";
        flagBtn2 = true;
    }
});
//button three.
btn3.addEventListener("click", function() {
    if(flagBtn3) {
        logo.style.boxShadow = "10px 10px 5px grey";
        flagBtn3 = false;
    } else {
        logo.style.boxShadow = "none";
        flagBtn3 = true;
    }
});